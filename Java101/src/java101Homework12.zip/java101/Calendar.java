package java101;

public class Calendar {
	public Calendar()
	{
		
	}
	public String daysOfMonth(int monthNumber)
	{
		if(monthNumber > 0 && monthNumber <= 12)
		{
			if((monthNumber % 2 == 1 && monthNumber <= 7) || (monthNumber % 2 == 0 && monthNumber >= 8 ))
			{
				return "31";
			} else if (monthNumber == 2)
			{
				return "28";
			}	
			return "30";
		}	
		return "The number you have given is an invalid month. Please try again.";
	}
}

