package java101;

/**
 * A int array that can be changed using the methods in this class. .
 * @author Wesley
 */

public class IntArrays 
{
	private int arraySize;
	private int[] array;
	
	/**
	 * Constructs a new int array with a length of 10.
	 */
	public IntArrays()
	{
		arraySize = 0;
		array = new int[10];
	}
	
	/**
	 * Constructs a new int array with a length of initialCapacity.	
	 * @param initialCapacity The initial length of the array.
	 */
	
	public IntArrays(int initialCapacity)
	{
		arraySize = 0;
		array = new int[initialCapacity];
	}
	
	/**
	 * Prints the number at the specified value in the array.
	 * @param index The index of the number to be printed.
	 * @return The number at the specified index in the array.
	 */
	public int get(int index)
	{
		return array[index];
	}
	
	/**
	 * Returns the length of the array.	
	 * @return The length of the array.
	 */
	public int size()
	{
		return arraySize;
	}
	
	/**
	 * Tells you if the array is empty.
	 * @return Returns true when the array is empty, and false when the array is not empty.
	 */
	public boolean isEmpty()
	{
		return (arraySize == 0);
	}
	
	/**
	 * Finds the smallest number in an array.
	 * @return The smallest number in the array.
	 */
	public int min()
	{
		int minNumber = array[0];
		for (int element : array) {
			if(element < minNumber)
			{
				minNumber = element;
			}
		}			
		return minNumber;
	}
	/**
	 * Finds the biggest number in the array.
	 * @return The biggest number in the array.
	 */
	public int max()
	{
		int maxNumber = array[0];
		for (int element : array) {
			if(element > maxNumber)
			{
				maxNumber = element;
			}
		}			
		return maxNumber;
	}
	/**
	 * Finds the sum of the elements in the array.
	 * @return The sum of the elements in the array.
	 */
	public int sum()
	{
		int sum = 0;
		for (int element : array)
		{
			sum += element;
		}
		return sum;
	}
	/**
	 * Finds the average of the numbers in the array.
	 * @return The average of the numbers in the array.
	 */
	public double average()
	{
		double sum = this.sum();
		return sum / arraySize;
	}	
	/**
	 * Adds a number at the end of the array; increases length if necessary.
	 * @param number The number you want to add in. 
	 * @return True when successful.
	 */
	public boolean add(int number)
	{
		if(arraySize < array.length)
		{
			array[arraySize] = number;
		}
		else
		{
			int[] newArray = new int[array.length * 2];
			array[arraySize] = number;
			newArray = array.clone();
			array = newArray;
		}
		arraySize++;
		return true;

	}
	/**
	 * Adds a number to the array at a certain index.
	 * @param index The index at which the number is inserted into.
	 * @param number The number that is to be inserted at the index.
	 * @return True if successful.
	 */
	public boolean add(int index, int number)
	{
		if(index < arraySize)
		{
			if(index < arraySize)
			{
				if(array[index] == 0)
				{
					array[index] = number;
					arraySize++;
					return true;
				}
			}
		}
		return false;	
	}
	/**
	 * Removes an element at the specified index, and moves in elements on the right to fill the gap.
	 * @param index The index of the element that is to be removed.
	 * @return The removed element.
	 */
	public int remove(int index)
	{
		int element = array[index];
		for(int i = arraySize - 1; i >= index; i--)
		{
			array[i] = array[i + 1];
		}
		arraySize--;
		return element;


	}
	/**
	 * Checks if the array has the given number as an element.
	 * @param number The number that is being checked for in the array.
	 * @return True if the number is in the array, false if the number is not in the array.
	 */
	public boolean contains(int number)
	{
		for (int element : array) 
		{
			if(element == number)
			{
				return true;
			}
		}
		return false;
	}
	/**
	 * Finds the index of the first occurrence of the given number.
	 * @param number The number that is searched for in the array.
	 * @return The index of the first occurrence of the number, or -1 if the number is not in the array.
	 */
	public int indexOf(int number)
	{
		for (int i = 0; i < array.length; i++) 
		{
			if(array[i] == number)
			{
				return i;
			}
			
		}
		return -1;
	}
	/**
	 * Finds the index of the last occurrence of the given number.
	 * @param number The number that is searched for in the array.
	 * @return The index of the last occurrence of the number, or -1 if the number is not in the array.
	 */
	
	public int lastIndexOf(int number)
	{
		for (int i = array.length - 1; i >= 0; i--)
		{
			if(array[i] == number)
			{
				return i;
			}
		}
		return -1;
	}
	/**
	 * Replaces the integer at the specified position in the array with the specified integer.
	 * @param index The index to set to the integer.
	 * @param integer The number to replace the current number in the index.
	 */
	
	public void set(int index, int integer)
	{
		if(index < array.length && index >= 0)
		{
			array[index] = integer;
		}
	}
	/**
	 * Removes all of the elements from the array.
	 */
	public void clear()
	{
		arraySize = 0;
	}
	/**
	 * Returns a new copy of the array.
	 */
	public int[] clone()
	{
		int[] newArray = new int[array.length];
		for (int i = 0; i < arraySize; i++)
		{
			newArray[i] = array[i];
		}
		return newArray;
	}
	/**
	 * Returns a new array containing only a portion of this array starting with fromIndex (inclusive) to toIndex (exclusive).
	 * @param fromIndex Where the portion of the new array starts(inclusive).
	 * @param toIndex Where the portion of the new array ends(exclusive).
	 * @return The new array.
	 */
	
	public int[] subList(int fromIndex, int toIndex)
	{
		int[] newArray = new int[toIndex - fromIndex];
		for(int i = fromIndex; i < toIndex; i++)
		{
			newArray[i] = array[i];
		}
		return newArray;
		
	}
	/**
	 * Increase the capacity of the array, if necessary, to ensure that it can hold at least the number of elements specified by the minimum capacity argument.
	 * @param minCapacity The minimum capacity that is used to see if the capacity of the array must be increased.
	 */
	public void ensureCapacity(int minCapacity)
	{
		if(array.length < minCapacity)
		{
			int[] newArray = new int[array.length * 2];
			newArray = array.clone();
			array = newArray;
			
			
		}
		
	}
	/**
	 * Swaps 2 elements of the array.
	 * @param index1 The index of the element that is going to be swapped.
	 * @param index2 The index of the element that will be swapped with index1.
	 * @return True if the swap is successful, and false if the swap is unsuccessful.
	 */
	public boolean swap(int index1, int index2)
	{
		if(index1 < array.length && index2 < array.length)
		{
			int holder = array[index1];
			array[index1] = array[index2];
			array[index2] = holder;
			return true;
		}
		return false; 
	}
	/**
	 * Prints all the elements of an array, with commas separating the elements. 
	 */
	public void print()
	{
		if (arraySize >= 1) 
		{
		    System.out.print(array[0]);
		}

		for (int i = 1; i < arraySize; i++) 
		{ 
		     System.out.print((", " + array[i]));
		}
		System.out.println(" ");
	}
	/*
	 * Creates and returns a new array that is a numerically sorted version of the array. 
	 */
	public int[] oldSorted()
	{
		int[] newArray = array.clone();
		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				int temp = 0;
				if (array[i] > array[j]) {
					temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		return newArray;
		
	}
	/*
	 * Numerically sorts an array.
	 */
	public int[] oldSort()
	{
		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				int temp = 0;
				if (array[i] > array[j]) {
					temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		return array;
		
	}
	/*
	 * Finds out if a number is present in an array.
	 */
	public boolean find(int number)
	{
		boolean b = false;
		int temp = this.lastIndexOf(number - 1);
		if(temp + 1 < array.length)
		{
			b = true;
		}
		return b;
	}
}
	
	

	


