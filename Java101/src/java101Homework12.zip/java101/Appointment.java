package java101;

public class Appointment 
{
	private int startTimeHour;
	private int startTimeMinute;
	private int endTimeHour;
	private int endTimeMinute;
	private String name;
	public Appointment(int startTimeHour, int startTimeMinute, int endTimeHour, int endTimeMinute, String name)
	{
		this.startTimeHour = startTimeHour;
		this.startTimeMinute = startTimeMinute;
		this.endTimeHour = endTimeHour;
		this.endTimeMinute = endTimeMinute;
		this.name = name;
	}
	public boolean overlap(Appointment name)
	{
		if(this.endTimeHour <= name.startTimeHour)
		{	
			if((this.endTimeHour <  name.startTimeHour) || (this.endTimeHour == name.startTimeHour && this.endTimeMinute < name.startTimeMinute))
			{
				return false;
			} else 
			{
				return true;
			}
			
		} else if(name.endTimeHour <= this.endTimeHour)
		{
			if((name.endTimeHour <  this.startTimeHour) || (name.endTimeMinute < this.startTimeMinute && name.endTimeHour == this.startTimeHour))
			{
				return false;
			} else 
			{
				return true;
			}
		} else
		{
			return true;
		}
	}
}

