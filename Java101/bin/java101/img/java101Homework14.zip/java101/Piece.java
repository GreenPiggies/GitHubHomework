package java101;

public class Piece {
	private int x;
	private int y;
	private String royalty;
	private String color;
	public Piece(int x, int y, String color, String royalty)
	{
		this.x = x;
		this.y = y;
		this.royalty = royalty;
		this.color = color;
	}
	public boolean validMove(int x, int y)
	{
		if(royalty.equals("Crowned"))
		{
			if((x > 0 && x < 7) && (y > 0 && y < 7))
			{
				if((x - 1 == this.x || x + 1 == this.x) && (y - 1 == this.y || y + 1 == this.y))
				{
					return true;
				}
				return false;
			}
			else
			{
				return false;
			}
		} else if(color.equals("Light"))
		{
			if((x > 0 && x < 7) && (y > 0 && y < 7))
			{
				if((x - 1 == this.x || x + 1 == this.x) && y - 1 == this.y)
				{
					return true;
				}
				return false;
			}
		else
		{
			if((x > 0 && x < 7) && (y > 0 && y < 7))
			{
				if((x - 1 == this.x || x + 1 == this.x) && y + 1 == this.y)
				{
					return true;
				}
				return false;
			}
			return false;
		}
	}
return false;

			
		//commented this out just in case i need it someday
		/*if((x - 1 == this.x && x >= 0 && x <= 7) && (y - 1 == this.y && y >= 0 && y <= 7 )) 
		{
			return true;
		} else if((x + 1 == this.x && x >= 0 && x <= 7) && (y - 1 == this.y && y >= 0 && y <= 7 ))
		{
			return true;
		} else if((x + 1 == this.x && x >= 0 && x <= 7) && (y + 1 == this.y && y >= 0 && y <= 7 ))
		{
			return true;
		} else if ((x - 1 == this.x && x >= 0 && x <= 7) && (y + 1 == this.y && y >= 0 && y <= 7 ))
		{
			return true;
		} else
		{
			return false;
		}*/
	}
}
