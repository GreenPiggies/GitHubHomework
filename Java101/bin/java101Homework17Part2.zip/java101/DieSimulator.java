package java101;

import java.util.Random;

public class DieSimulator {
	
	public static void main(String[] args)
	{
		Random dieSimulator = new Random();
		System.out.println("You've rolled a " + (dieSimulator.nextInt(6) + 1) + "!");
		

	}

}
