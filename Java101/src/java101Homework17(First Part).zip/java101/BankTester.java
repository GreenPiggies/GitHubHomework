package java101;

public class BankTester {
	
	public static void main(String[] args) {
		BankAccount wesley = new BankAccount(1000, 1066, "Wesley");
		wesley.deposit(20.00);
		System.out.println(wesley.getBalance());
		BankAccount jonathan = new BankAccount(50, 1000, "Jonathan");
		jonathan.deposit(20);
		System.out.println(jonathan.getBalance());
		wesley.transfer(20, jonathan);	
		wesley.deposit(696969);
		System.out.println(wesley.getBalance());
		System.out.println(jonathan.getBalance());
		
		BankAccount [] accountArray = new BankAccount [3];
		accountArray[0] = new BankAccount(7);
		accountArray[1] = new BankAccount(11);
		accountArray[2] = new BankAccount(19);
		
		System.out.println(accountArray[0].total(accountArray));
		
		System.out.println(wesley.getInterest());


		
		


	}

}
