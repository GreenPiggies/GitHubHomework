package java101;

public class BankArray {

	public static void main(String[] args) {
		
		BankAccount[] ba = new BankAccount[3];
		ba[0] = new BankAccount(7);
		ba[1] = new BankAccount(14);
		ba[2] = new BankAccount(21);
		double totalBalance = 0;
		for(BankAccount eachAccount : ba)
		{
		
			totalBalance += eachAccount.getBalance();
			System.out.println(eachAccount.getBalance());
			
		}
		System.out.println(totalBalance);
	}		

	

}
