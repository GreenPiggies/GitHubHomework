package java101;



public class RandomMethodTest {
	//Don't get the grading calculator, how to convert args[] to IntArrays[]?
	public static void main(String args[])
	{
		IntArrays[] temp = new IntArrays[args.length];
		for(int i = 0; i < args.length; i++)
		{
			temp[i] = Integer.parseInt(args[i]);
		}
		

	}
	public double findBiggest(double num1, double num2, double num3)
	{
	    if (num1 > num2) {
	        if (num3 > num1) {
	            return num3;
	        } 
	        return num1;	 
	    // num2 >= num1    
	    } else if (num1 > num3) {
	        return num2;
	    // num2 >= num1, num3 >= num1    
	    } else if (num3 > num2) {
	    	return num3;
	    }
	    // num2 >= num1, num3 >= num1, num2 >= num3
	    return num2;
	}
	    public String lexicographicOrder(String str1, String str2, String str3)
	    {
	        if (str1.compareTo(str2) < 0) {
	            if (str3.compareTo(str1) < 0) {
	    	            return str3 + ", " + str1 + ", " + str2;
	    	    }
	            else if (str2.compareTo(str3) < 0)
	            {
	                return str1 + ", " + str2 + ", " + str3;
	            }
	            return str1 + ", " + str3 + ", " + str2;
	        }
	        else if (str1.compareTo(str3) < 0) {
	    	    return str2 + ", " + str1 + ", " + str3;
	        } 
	        else if (str3.compareTo(str2) < 0) {
	    	   	return str3 + ", " + str2 + ", " + str1;
	    	}
	        return str2 + ", " + str3 + ", " + str1;
	    
	   
	}
	    public int firstSpace(String str)
	    {
	        for(int i = 0; i < str.length(); i++)
	        {
	        	char c = str.charAt(i);
	        	if(c == ' ')
	        	{
	        		return i;
	        	}
	        }
	        return -1;
	    }
	    public int lastSpace(String str)
	    {
	        for(int i = str.length() - 1; i > 0; i--)
	        {
	            char c = str.charAt(i);
	            if(c == ' ')
	    	    {
	    	        return i;
	    	    }
	        }
	    	return -1;
	    }
	    public int findSpaces(String str)
	    {
            int numSpaces = 0;
	        for(int i = 0; i < str.length(); i++)
	        {
	            char c = str.charAt(i);
	            if(c == ' ')
	            {
	    	        numSpaces++;
	    	    }
	        }
	    	if(numSpaces > 0)
	    	{
	    		return numSpaces;
	    	} else
	    	{
	    		return -1;
	    	}
	    }
	    public int findSentences(String str)
	    {
            int numSentence = 0;
	        for(int i = 0; i < str.length(); i++)
	        {
	            char c = str.charAt(i);
	            if(i + 2 < str.length())
	            {
	            	if((c == '.' || c == '?' || c == '!') && (Character.isUpperCase(str.charAt(i + 2)) || str.charAt(i + 2) == ' '))
	            	{
	            		numSentence++;
	            	}
	            } else if(c == '.' || c == '?' || c == '!')
	            {
	            	numSentence++;
	            }
	        }
	    	if(numSentence > 0)
	    	{
	    		return numSentence;
	    	} else
	    	{
	    		return -1;
	    	}
	    }
}
