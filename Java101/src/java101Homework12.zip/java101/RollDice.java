package java101;

import java.util.Random;

public class RollDice {

	public static void main(String[] args) {
		Random rollDice = new Random();
		int roll2 = 0;
		int roll3 = 0;
		int roll4 = 0;
		int roll5 = 0;
		int roll6 = 0;
		int roll7 = 0;
		int roll8 = 0;
		int roll9 = 0;
		int roll10 = 0;
		int roll11 = 0;
		int roll12 = 0;
		for(int i = 0; i < 300; i++)
		{
			int firstRoll = rollDice.nextInt(6) + 1;
			int secondRoll = rollDice.nextInt(6) + 1;
			int roll = firstRoll + secondRoll;
			
			if(roll == 2)
			{
				roll2++;
			} else if(roll == 3)
			{
				roll3++;
			} else if(roll == 4)
			{	
				roll4++;
			} else if(roll == 5)
			{
				roll5++;
			} else if(roll == 6)
			{
				roll6++;
			} else if(roll == 7)
			{
				roll7++;
			} else if(roll == 8)
			{
				roll8++;
			} else if(roll == 9)
			{
				roll9++;
			} else if(roll == 10)
			{
				roll10++;
			} else if(roll == 11)
			{
				roll11++;
			} else 
			{
				roll12++;
			}
			
		} //<-- end of the for loop
		System.out.print("\nTwo: " + roll2 + " - ");
		for(int x = 1; x <= roll2; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nThree: " + roll3 + " - ");
		for(int x = 1; x <= roll3; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nFour: " + roll4 + " - ");
		for(int x = 1; x <= roll4; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nFive: " + roll5 + " - ");
		for(int x = 1; x <= roll5; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nSix: " + roll6 + " - ");
		for(int x = 1; x <= roll6; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nSeven: " + roll7 + " - ");
		for(int x = 1; x <= roll7; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nEight: " + roll8 + " - ");
		for(int x = 1; x <= roll8; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nNine: " + roll9 + " - ");
		for(int x = 1; x <= roll9; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nTen: " + roll10 + " - ");
		for(int x = 1; x <= roll10; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nEleven: " + roll11 + " - ");
		for(int x = 1; x <= roll11; x++)
		{
			System.out.print("*");
		}
		System.out.print("\nTwelve: " + roll12 + " - ");
		for(int x = 1; x <= roll12; x++)
		{
			System.out.print("*");
		}
		
	
	
		
	}
}
