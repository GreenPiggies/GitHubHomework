package java101;

/**
 * A bank account has a balance that can be changed by deposits and withdrawals.
 * @author Wesley
 */
public class BankAccount {
	private double balance;
	
	private int accountNumber;
	
	private String accountName;
	
	private static final double INTEREST_RATE = 0.013;
	
	public BankAccount(int initialBalance, int newAccountNumber, String newAccountName )
	{
		balance = initialBalance;
		accountNumber = newAccountNumber;
		accountName = newAccountName;
	}
	
	/**
	 * Constructs a bank Account with a zero balance.
	 */
	public BankAccount(){
		this(0, 0, "None");
	}
	/**
	 * Constructs a bank account with an initial balance.
	 * @param initialBalance Starting balance amount
	 */
	public BankAccount(int initialBalance){
		this(initialBalance, 0, "None");
	}
	/**
	 * Deposits money into the bank account.
	 * @param amount The amount to deposit.
	 */
	public void deposit(double amount)
	{
		balance = balance + amount;
	}
	/**
	 * Withdraws money from the bank account.
	 * @param amount The amount to withdraw
	 */
	public void withdraw(double amount)
	{
		balance = balance - amount;
	}
	/**
	 * Gets the current balance of the bank account.
	 * @return The current balance.
	 */
	public double getBalance()
	{
		return balance;
	}
	
	public int getAccountNumber()
	{
		return accountNumber;
	}
	
	public String getAccountName()
	{
		return accountName;
	}
	
	public double transfer(int transferAmount, BankAccount transferTo)
	{
		if (this != transferTo)
		{
		transferTo.deposit(transferAmount);
		withdraw(transferAmount);
		}
		return balance;
	}
	
	public double total(BankAccount [] ba)
	{
		double sum = 0;
		
		for(BankAccount each : ba)
		{
			if(this != each)
			{
				sum += each.getBalance();
			}
		}
		return sum;
	}
	
	public double getInterest()
	{
		return balance * INTEREST_RATE;
	}
	
	public boolean transaction(String transaction, int amount)
	{
		if(transaction.equals("deposit"))
		{
			this.deposit(amount);
			return true;
		} else if(transaction.equals("withdraw"))
		{
			this.withdraw(amount);			
			return true;
		} else 
		{
			return false;
		}
	}
	public boolean transaction(String transaction)
	{
		if(transaction.equals("getBalance"))
		{
			this.getBalance();
			return true;
		} 
		return false;
	}
	
}



