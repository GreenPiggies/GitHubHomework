package java101;

public class Types {
	public String identify(boolean input){
		return "Boolean";
	}
	public String identify(byte input){
		return "Byte";
	}
	public String identify(char input){
		return "Character";
	}
	public String identify(short input){
		return "Short";
	}
	public String identify(int input){
		return "Integer";
	}
	public String identify(long input){
		return "Long";
	}
	public String identify(float input){
		return "Float";
	}
	public String identify(double input){
		return "Double";
	}
	public String identify(String input){
		return "String";
	}
}
