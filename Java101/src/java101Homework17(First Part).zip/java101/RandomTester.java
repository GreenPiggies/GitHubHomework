package java101;

public class RandomTester {

	public static void main(String[] args) {
		
		Appointment school = new Appointment(7, 45, 17, 0, "School");
		Appointment dentist = new Appointment(14, 30, 16, 0, "Dentist");
		Appointment breakfast = new Appointment(7, 15, 7, 50, "Breakfast");
		Appointment homework = new Appointment(17, 15, 20, 50, "Homework");

		System.out.println(school.overlap(dentist));
		System.out.println(school.overlap(breakfast));
		System.out.println(school.overlap(homework));
	}

}
