package java101;

public class Test {

	public static void main(String[] args) {
		
		String greeting = "Hello WORLD";
		String word = "world";
		System.out.println(greeting.replace(word.toUpperCase(), "Dave").length());
		
	}
}
