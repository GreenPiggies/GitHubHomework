package java101;

public class LetterType {
		public LetterType()
		{
			
		}
		public String determineType(String input)
		{
			if (input.length() == 1)
			{
				if (input.matches("[a-zA-Z]"))
				{
					if (input.matches("[aAeEiIoOuU]"))
					{
						return("Vowel");
					}
					return("Consonant");
				}	
				return("This is not a valid input. Please input 1 letter.");
			} 	
			return("This is not a valid input. Please input 1 letter.");
		} 
	}

	
	

